# OOPProject
Schedule simulator
to run simulator type 
python3 main.py 

once the simulator is runing you will be given options of what you want to do 
press 1 to create a csv file for all the simulations requested note 
  note: when simulation is runing the finshed tasks are printed out 
  the round robbin take some time to run   
press 2 to run a custom simulation you will be asked what you would like to use and 
what you would like to use for arivale rate and avg Service time 


